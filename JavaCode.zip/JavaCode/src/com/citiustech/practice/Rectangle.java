package com.citiustech.practice;

public class Rectangle extends GraphicObject {
	
	void draw(){
		System.out.println("Drawing a rectangle");
	}
	
	void resize(){
		System.out.println("Resizing a rectangle");
	}

}
