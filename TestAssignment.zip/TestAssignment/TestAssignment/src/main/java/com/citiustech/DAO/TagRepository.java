package com.citiustech.DAO;

import java.util.Collection;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.citiustech.Model.Article;
import com.citiustech.Model.Tag;

@Repository
public interface TagRepository extends JpaRepository<Tag, Integer> {

	Collection<Tag> findByArticle(Article a);
}
