package com.citiustech.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestBody;

import com.citiustech.DAO.ArticleRepository;
import com.citiustech.DAO.TagRepository;
import com.citiustech.Exception.ResourceNotFoundException;
import com.citiustech.Model.Article;
import com.citiustech.Model.Tag;

@Service
public class ArticleService {
	
	@Value("#{'${article.blocklist}'.split(',')}") 
	private List<String> blockList;
	
	@Autowired
	private ArticleRepository articleRepository;
	
	@Autowired
	private TagRepository tagRepository;
	
	public void saveArticle(@RequestBody Article article){
		checkBlockList(article);
		article.setId((int)(System.currentTimeMillis() % 1000+1));
		List<Tag> list = article.getTags();
		article.setTags(null);
		articleRepository.save(article);
		int i=0;
		for (Tag tag : list) {
			tag.setArticle(article);
			tag.setId((int)(System.currentTimeMillis() % 1000000 + i));
			tagRepository.save(tag);
			++i;
		}
	}
	
	public List<Article> getAllArticle(){
		List<Article> articleList =  articleRepository.findAll();
		for (Article article : articleList) {
			List<Tag> tagList = article.getTags();
			for (Tag tag : tagList) {
				tag.setArticle(null);
			}
		}
		return articleList;
	}
	
	public Article getArticleById(int id){
		Article a = articleRepository.findById(id);
		if(a == null){
			throw new ResourceNotFoundException("Article Not Found");
		}
		List<Tag> tagList = a.getTags();
		for (Tag tag : tagList) {
			tag.setArticle(null);
		}
		return a;
	}
	
	public Article getArticleByTitle(String n){
		Article a = articleRepository.findByTitle(n);
		if(a == null){
			throw new ResourceNotFoundException("Article Not Found");
		}
		List<Tag> tagList = a.getTags();
		for (Tag tag : tagList) {
			tag.setArticle(null);
		}
		return a;
	}
	
	public void updateArticle(Article article){
		checkBlockList(article);
		System.out.println(article);
		Article check = articleRepository.findById(article.getId());
		if(check == null){
			throw new ResourceNotFoundException("Article Not Found");
		}
		List<Tag> list = article.getTags();
		article.setTags(null);
		articleRepository.save(article);
		for (Tag tag : list) {
			tag.setArticle(article);
			tagRepository.save(tag);
		}
		
	}
	
	public void deleteArticle(int id){
		
	}
	
	public void checkBlockList(Article article){
		for (String bl : blockList) {
			if(article.getContent().contains(bl)){
				throw new ResourceNotFoundException("Article content contains forbidden words.");
			}
		}
	}
}
