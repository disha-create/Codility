package com.citiustech.training.demo1.service;

import java.util.Collection;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.citiustech.training.demo1.model.Person;



@Service
public class PersonService {

	/*@Autowired
	private SessionFactory sessionFactory;
	
	public Collection<Person> getAll(){
		Session session = sessionFactory.openSession();
		
	
		Query query = session.createQuery("FROM person_data");
		Collection<Person> persons = query.list();
		
		session.close();
		return persons;
	}
	
	
	public void savePerson(Person person){
		Session session = sessionFactory.openSession();
		Transaction tx = session.beginTransaction();
		session.save(person);
		tx.commit();
		session.close();
	}*/
	
	@Autowired
	private EntityManager entityManager;
	
	public List<Person> findAll(){
		
		TypedQuery<Person> query = entityManager.createQuery("FROM Person", Person.class);
		return query.getResultList();
	}
}
