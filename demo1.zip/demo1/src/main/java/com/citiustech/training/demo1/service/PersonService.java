package com.citiustech.training.demo1.service;

import java.util.Collection;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.citiustech.training.demo1.model.Person;

@Service
public class PersonService {
	
	@Autowired
	private SessionFactory sessionFactory;
	
	
	
	public Collection<Person> findAll() {
		
		Session session = sessionFactory.openSession();
		
		
		Query query = session.createQuery("FROM Person");
		Collection<Person> persons = query.list();
		
		System.out.println(persons);
		
		
		for (Person person : persons) {
			System.out.println(person.abc());
		}
		
		
		
		session.close();
		
		
		
		return persons;
		
	}



	public void savePerson(Person person) {
		// TODO Auto-generated method stub
		
		
		
		Session session = sessionFactory.openSession();
		Transaction tx = session.beginTransaction();
			
		
		
		session.save(person);
		
		
		tx.commit();
		session.close();
		
		
		
		
	}
	
	
	
	
}
