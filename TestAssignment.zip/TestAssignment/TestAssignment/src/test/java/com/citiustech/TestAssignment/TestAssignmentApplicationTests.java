package com.citiustech.TestAssignment;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TestAssignmentApplicationTests {

	@Test
	void contextLoads() {
	}

}
