package com.citiustech.practice;

public abstract class GraphicObject {
	
	int x;
	int y;
	
	GraphicObject() {
		System.out.println("Graphic Object Instantiated");
	}
	
	void MoveTo(int x, int y){
		System.out.println(x+y);
	}
	
	

	abstract void draw();
	abstract void resize();
}
