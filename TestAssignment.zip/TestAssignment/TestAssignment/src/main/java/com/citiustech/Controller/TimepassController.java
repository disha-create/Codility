package com.citiustech.Controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.citiustech.DAO.ArticleRepository;
import com.citiustech.DAO.TagRepository;
import com.citiustech.Model.Article;
import com.citiustech.Model.Tag;
import com.citiustech.Service.ArticleService;

@RestController
@RequestMapping("/hello")
public class TimepassController {

	@Autowired
	private ArticleService articleService;
	
	@GetMapping
	public Article hello(){
		Article a = new Article();
		a.setTitle("Mahesh");
		a.setContent("Hey Mahesh.....!");
		
		Tag t1 = new Tag();
		t1.setTag("H");
		
		Tag t2 = new Tag();
		t2.setTag("M");
		
		List<Tag> list = new ArrayList<Tag>();
		list.add(t1);
		list.add(t2);
		
		a.setTags(list);
		
		return a;
	}
	
	@PostMapping
	public void saveArticle(@RequestBody Article article){
//		articleService.saveArticle(article);
		System.out.println(article);
	}
}
