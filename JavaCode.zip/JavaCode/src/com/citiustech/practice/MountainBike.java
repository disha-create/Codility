package com.citiustech.practice;

public class MountainBike extends bicycle{

	public int seatHeight;
	
	public MountainBike(int gear, int speed) {
		super(gear, speed);
		// TODO Auto-generated constructor stub
	}

	public MountainBike(int gear, int speed, int seatHeight) {
		super(gear, speed);
		this.seatHeight = seatHeight;
	}

	public void setHeight(int newValue){
		this.seatHeight=newValue;
	}
}
