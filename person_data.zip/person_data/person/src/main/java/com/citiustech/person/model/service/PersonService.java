package com.citiustech.person.model.service;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.citiustech.person.model.Person;

@Service
public class PersonService {
	
	@Autowired
	private EntityManager entityManager;
	
	public List<Person> findAll(){
		TypedQuery<Person> query = entityManager.createQuery("FROM Person", Person.class);
		return query.getResultList();
	}
}
