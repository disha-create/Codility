package com.citiustech.training.demo1.controller;

import java.util.Collection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.citiustech.training.demo1.model.Person;
import com.citiustech.training.demo1.service.PersonService;

@RestController
@RequestMapping("/person")
public class PersonController {

	@Autowired
	private PersonService personService;
	
	
	@GetMapping(value="/getAll")
	public Collection<Person> getAllPersons(){
		return personService.getAll();
	}
	
	@PostMapping(value="save",consumes="application/json")
	public void savePerson(@RequestBody Person person){
		personService.savePerson(person);
	}
}
