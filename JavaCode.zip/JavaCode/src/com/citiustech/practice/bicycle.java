package com.citiustech.practice;

public class bicycle {
	
	protected int gear;
	protected int speed;
	
	public bicycle(int gear, int speed){
		this.gear = gear;
		this.speed=speed;
	}
	
	public void setGear(int newValue){
		gear=newValue;
	}
	
	public void speedUp(int increment){
		speed+=increment;
	}
	
	public void applyBreak(int decrement){
		speed-=decrement;
	}

}
