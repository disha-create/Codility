package com.citiustech.practice;

public class Circle extends GraphicObject {

	void draw(){
		System.out.println("Drawing a cirle");
	}
	
	void resize(){
		System.out.println("Resizing a circle");
	}

}
